# David Strasak - NÁVRH SYSTÉMU PRO DÁLKOVÉ SPOUŠTĚNÍ DOPRAVNÍKŮ
Závěrená práce zpracovaná uvnitř neoficiální VUT šablony závěrečných prací. 

# Overleaf
* Klon původní šablony existuje na stránce projektu Overleaf: [VUT Template](https://www.overleaf.com/read/tpzfxwqztqxd)
